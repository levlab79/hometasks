# Задание 1.
# Создадим 4 переменные разных типов и выведем их на экран.
# Переменная типа int.
a_int = 21
print(a_int)
# Переменная типа float.
a_float = 3.21
print(a_float)
# Переменная типа str.
a_str = 'Strange string.'
print(a_str)
# Переменная типа bool.
a_bool = False
print(a_bool)
# Запросим у пользователя несколько число и строк, и сохраним их в переменные.
# b_int = int(input('Введите целое число: '))
b_int = int('21')
# b_float = float(input('Введите число с плавающей точкой: '))
b_float = float('4.02')
# b_str = input('Введите строку: ')
b_str = 'some string'
# Выведем их на экран.
print(b_int)
print(b_float)
print(b_str)
