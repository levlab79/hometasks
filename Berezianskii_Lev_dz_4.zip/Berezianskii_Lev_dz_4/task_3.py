print([number for number in range(20, 241) if not (number % 20 and number % 21)])
